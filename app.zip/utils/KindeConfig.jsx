import { KindeSDK } from "@kinde-oss/react-native-sdk-0-7x";

export const client = new KindeSDK(
  "https://dancey.kinde.com",
  "exp://192.168.1.134:8081",
  "a45071b7a4ca47cbb4831db7f370fe0b",
  "exp://192.168.1.134:8081"
);
