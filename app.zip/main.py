from flask import Flask, request, jsonify, send_file
import qrcode
import os

app = Flask(__name__)

@app.route('/validate-qr', methods=['POST'])
def validate_qr():
    received_data = request.json.get('qrData', '')
    expected_data = "Dancey"  # Or any logic to fetch expected data

    isValid = (received_data == expected_data)
    return jsonify({"isValid": isValid})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0')
